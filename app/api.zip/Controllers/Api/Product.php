<?php
namespace App\Controllers\Api;

use App\Controllers\BaseAuthController;

class Product extends BaseAuthController
{
    protected $session;
    protected $validation;
    protected $request;

    public function __construct()
    {
        $this->session    = \Config\Services::session();
        $this->validation = \Config\Services::validation();
        $this->request    = \Config\Services::request();
    }
public function get_categories()
    {
        $m_category = new \App\Models\M_category();
        $response['categoies'] = $m_category->get_categories();
        return json_encode($response);
    }public function get_products()
    {
        $m_product = new \App\Models\M_product();
        $response['products'] = $m_product->get_products();
        return json_encode($response);
    }
}
?>