<?php

namespace App\Controllers;

use App\Models\M_order;

class Order extends BaseController
{
    protected $session;
    protected $orderModel;
    protected $data = [];

    public function __construct()
    {
        $this->session = \Config\Services::session();
        $this->orderModel = new M_order();
    }

    private function setCommonData()
    {
        $this->data['admin'] = [
            'admin_name' => session()->get('admin_name'),
            'type'       => session()->get('type')
        ];
    }

    public function index()
    {
        if (!$this->session->get('logged_in')) {
            return redirect()->to('/');
        }

        $this->setCommonData();

        $this->data['orders'] = $this->orderModel
            ->orderBy('id', 'DESC')
            ->findAll();

        echo view('includes/header', $this->data);
        echo view('includes/sidebar', $this->data);
        echo view('order_view', $this->data);
        echo view('includes/footer');
    }

    public function status($id)
    {
        $status = $this->request->getPost('status');

        $this->orderModel->update($id, [
            'status' => $status
        ]);

        return redirect()->to(base_url('order'));
    }
}