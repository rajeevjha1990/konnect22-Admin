<?php

if(isset($product)){

    $id           = $product->id ?? '';
    $vendor_id    = $product->vendor_id ?? '';
    $category_id  = $product->category_id ?? '';
    $product_name = $product->name ?? '';
    $description  = $product->description ?? '';
    $price        = $product->price ?? '';
    $sale_price   = $product->sale_price ?? '';
    $stock        = $product->stock ?? '';
    $image        = $product->image ?? '';
    $status       = $product->status ?? 'Active';

}else{

    $id           = '';
    $vendor_id    = '';
    $category_id  = '';
    $product_name = '';
    $description  = '';
    $price        = '';
    $sale_price   = '';
    $stock        = '';
    $image        = '';
    $status       = 'Active';
}
?>

<style>

.form-card{
    background:#fff;
    max-width:950px;
    margin:auto;
    border-radius:12px;
    padding:25px;
    box-shadow:0 5px 18px rgba(0,0,0,.08);
}

.form-title{
    text-align:center;
    margin-bottom:25px;
    color:#0f5132;
    font-size:32px;
    font-weight:700;
}

.grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:18px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group.full{
    grid-column:1 / -1;
}

.form-group label{
    margin-bottom:6px;
    font-weight:600;
    color:#333;
}

.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:10px 12px;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
}

.form-group textarea{
    resize:vertical;
}

.action-box{
    text-align:center;
    margin-top:25px;
}

.save-btn{
    background:#198754;
    color:#fff;
    border:none;
    padding:10px 25px;
    border-radius:8px;
    cursor:pointer;
    font-size:15px;
}

.save-btn:hover{
    background:#157347;
}

.back-btn{
    background:#6c757d;
    color:#fff !important;
    text-decoration:none;
    padding:10px 18px;
    border-radius:8px;
    margin-left:10px;
    display:inline-block;
}

.preview-img{
    width:120px;
    height:120px;
    object-fit:cover;
    border-radius:10px;
    border:1px solid #ddd;
}

@media(max-width:768px){

    .grid{
        grid-template-columns:1fr;
    }

    .form-title{
        font-size:26px;
    }

}
</style>

<div class="content">

    <div style="text-align:right;margin-bottom:15px;">
        <a href="javascript:history.back()" class="back-btn">
            <i class="fa fa-arrow-left"></i> Back
        </a>
    </div>

    <div class="form-card">

        <h2 class="form-title">
            <?= empty($id) ? 'Add Product' : 'Edit Product'; ?>
        </h2>

        <form method="post"
              action="<?= base_url('product/save') ?>"
              enctype="multipart/form-data">

            <input type="hidden"
                   name="id"
                   value="<?= esc($id) ?>">

            <div class="grid">

                <div class="form-group">
                    <label>Vendor *</label>

                    <select name="vendor_id" required>

                        <option value="">Select Vendor</option>

                        <?php foreach($vendors as $vendor){ ?>

                            <option value="<?= $vendor->id ?>"
                                <?= $vendor_id == $vendor->id ? 'selected' : '' ?>>

                                <?= esc($vendor->shop_name) ?>

                            </option>

                        <?php } ?>

                    </select>
                </div>

                <div class="form-group">

                    <label>Category *</label>

                    <select name="category_id" required>

                        <option value="">Select Category</option>

                        <?php foreach($categories as $cat){ ?>

                            <option value="<?= $cat['id'] ?>"
                                <?= $category_id == $cat['id'] ? 'selected' : '' ?>>

                                <?= esc($cat['name']) ?>

                            </option>

                        <?php } ?>

                    </select>

                </div>

                <div class="form-group">

                    <label>Product Name *</label>

                    <input type="text"
                           name="product_name"
                           value="<?= esc($product_name) ?>"
                           required>

                </div>

                <div class="form-group">

                    <label>Stock *</label>

                    <input type="number"
                           name="stock"
                           value="<?= esc($stock) ?>"
                           required>

                </div>

                <div class="form-group">

                    <label>Price *</label>

                    <input type="number"
                           step="0.01"
                           name="price"
                           value="<?= esc($price) ?>"
                           required>

                </div>

                <div class="form-group">

                    <label>Sale Price</label>

                    <input type="number"
                           step="0.01"
                           name="sale_price"
                           value="<?= esc($sale_price) ?>">

                </div>

                <div class="form-group">

                    <label>Status</label>

                    <select name="status">

                        <option value="Active"
                            <?= $status == 'Active' ? 'selected' : '' ?>>
                            Active
                        </option>

                        <option value="Inactive"
                            <?= $status == 'Inactive' ? 'selected' : '' ?>>
                            Inactive
                        </option>

                    </select>

                </div>

                <div class="form-group">

                    <label>Product Image</label>

                    <input type="file" name="image">

                </div>

                <?php if(!empty($image)){ ?>

                    <div class="form-group">

                        <label>Current Image</label>

                        <img src="<?= base_url('uploads/products/'.$image) ?>"
                             class="preview-img">

                    </div>

                <?php } ?>

                <div class="form-group full">

                    <label>Description</label>

                    <textarea name="description"
                              rows="5"><?= esc($description) ?></textarea>

                </div>

            </div>

            <div class="action-box">

                <button type="submit" class="save-btn">

                    <?= empty($id)
                        ? 'Save Product'
                        : 'Update Product'; ?>

                </button>

                <a href="<?= base_url('product') ?>"
                   class="back-btn">

                    Cancel

                </a>

            </div>

        </form>

    </div>

</div>