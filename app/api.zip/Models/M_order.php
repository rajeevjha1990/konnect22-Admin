<?php

namespace App\Models;

use CodeIgniter\Model;

class M_order extends Model
{
    protected $table = 'orders';

    protected $primaryKey = 'id';

    protected $allowedFields = [

        'order_no',

        'user_id',

        'order_name',
        'order_number',

        'order_address',
        'order_city',
        'order_pincode',
        'order_landmark',

        'subtotal',
        'shipping',
        'discount',
        'total',

        'payment_mode',
        'payment_status',

        'status',

        'estimated_delivery',

        'created_at'
    ];

    public function insert_order($data)
    {
        return $this->insert($data, true);
    }
public function get_orders($userid)
{
    return $this
        ->select('
            orders.*,
            order_items.product_id,
            order_items.qty,
            order_items.price,
            products.name as name,
            products.image_webp as image_webp
        ')
        ->join(
            'order_items',
            'order_items.order_id = orders.id',
            'left'
        )
        ->join(
            'products',
            'products.id = order_items.product_id',
            'left'
        )
        ->where('orders.user_id', $userid)
        ->orderBy('orders.id', 'DESC')
        ->findAll();
}
}
?>